@echo off
REM ScratchBird Windows Uninstallation Script

echo Uninstalling ScratchBird v0.5.0...

REM Check for administrator privileges
net session >nul 2>&1
if %errorlevel% neq 0 (
    echo Please run as administrator
    exit /b 1
)

set INSTALL_DIR=C:\Program Files\ScratchBird

REM Stop and uninstall service
net stop ScratchBird 2>nul
"%INSTALL_DIR%\bin\scratchbird.exe" -uninstall 2>nul

REM Remove from PATH (simplified)
echo Please manually remove %INSTALL_DIR%\bin from your PATH environment variable

REM Remove installation directory
rmdir /s /q "%INSTALL_DIR%"

echo ScratchBird uninstalled successfully!
pause
