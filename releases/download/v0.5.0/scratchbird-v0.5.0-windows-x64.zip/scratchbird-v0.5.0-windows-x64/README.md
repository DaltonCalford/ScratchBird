# ScratchBird v0.5.0 - Windows Distribution

## Quick Start

### Installation

```batch
REM Extract package and run as administrator
install.bat

REM Start service
net start ScratchBird

REM Verify installation
sb_isql.exe -z
```

## Package Contents

### Database Utilities
- **scratchbird** - Main database server
- **sb_isql** - Interactive SQL utility
- **sb_gbak** - Backup/restore utility
- **sb_gfix** - Database maintenance
- **sb_gsec** - Security management
- **sb_gstat** - Database statistics
- **sb_guard** - Process monitor
- **sb_svcmgr** - Service manager
- **sb_tracemgr** - Trace manager
- **sb_nbackup** - Incremental backup
- **sb_gssplit** - File splitter
- **sb_lock_print** - Lock analyzer

### Libraries
- **libsbclient** - Client library for applications

### Configuration
- **scratchbird.conf** - Main server configuration
- **databases.conf** - Database aliases
- **plugins.conf** - Plugin configuration

### Documentation
- Complete user documentation
- Examples and tutorials
- API reference

## Features

- **Hierarchical Schemas**: 8-level deep schema nesting
- **PostgreSQL Compatibility**: Network types, UUID IDENTITY, unsigned integers
- **Schema-Aware Database Links**: Distributed database connections
- **Modern Architecture**: C++17 GPRE-free implementation
- **Cross-Platform**: Native compilation for each platform

## Support

- **Documentation**: doc/ directory contains complete documentation
- **Examples**: examples/ directory contains sample configurations
- **Issues**: Report at https://github.com/dcalford/ScratchBird/issues

## Version Information

Build: SB-T0.5.0.1 ScratchBird 0.5 f90eae0
Platform: Windows
Architecture: x86_64
Package Date: Thu 17 Jul 2025 09:59:22 AM EDT

## License

ScratchBird is released under the Initial Developer's Public License (IDPL).
