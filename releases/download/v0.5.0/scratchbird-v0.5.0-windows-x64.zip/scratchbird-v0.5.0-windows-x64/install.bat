@echo off
REM ScratchBird Windows Installation Script

echo Installing ScratchBird v0.5.0...

REM Check for administrator privileges
net session >nul 2>&1
if %errorlevel% neq 0 (
    echo Please run as administrator
    exit /b 1
)

REM Create installation directory
set INSTALL_DIR=C:\Program Files\ScratchBird
mkdir "%INSTALL_DIR%" 2>nul
mkdir "%INSTALL_DIR%\bin" 2>nul
mkdir "%INSTALL_DIR%\lib" 2>nul
mkdir "%INSTALL_DIR%\conf" 2>nul
mkdir "%INSTALL_DIR%\doc" 2>nul
mkdir "%INSTALL_DIR%\examples" 2>nul

REM Copy files
copy bin\*.exe "%INSTALL_DIR%\bin\"
copy lib\*.dll "%INSTALL_DIR%\lib\"
copy conf\*.conf "%INSTALL_DIR%\conf\"
copy doc\*.* "%INSTALL_DIR%\doc\"
xcopy examples "%INSTALL_DIR%\examples\" /E /I /Q

REM Add to PATH
setx PATH "%PATH%;%INSTALL_DIR%\bin" /M

REM Install Windows service
"%INSTALL_DIR%\bin\scratchbird.exe" -install

echo ScratchBird installed successfully!
echo Service installed. Use "net start ScratchBird" to start the service.
echo Configuration files: %INSTALL_DIR%\conf\
echo Documentation: %INSTALL_DIR%\doc\

pause
