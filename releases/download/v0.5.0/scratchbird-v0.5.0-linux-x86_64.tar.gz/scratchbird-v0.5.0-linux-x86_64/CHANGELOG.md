# ScratchBird v0.5.0 - Release Notes

## New Features
- Complete hierarchical schema system (8 levels deep)
- PostgreSQL-compatible data types (INET, CIDR, MACADDR, UUID, etc.)
- Schema-aware database links with 5 resolution modes
- Modern C++17 GPRE-free implementation
- Cross-platform build system
- 12 comprehensive database utilities

## Improvements
- 96.3% code reduction from GPRE elimination
- Enhanced performance with optimized caching
- Complete ScratchBird branding (zero Firebird conflicts)
- Automated installation and service management
- Comprehensive documentation and examples

## Platform: Linux-x86_64
Build Date: Thu 17 Jul 2025 09:58:58 AM EDT
Build Version: SB-T0.5.0.1 ScratchBird 0.5 f90eae0
