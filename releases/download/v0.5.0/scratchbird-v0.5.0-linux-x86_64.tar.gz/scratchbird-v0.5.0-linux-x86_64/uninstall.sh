#!/bin/bash
# ScratchBird Uninstallation Script

set -e

INSTALL_PREFIX="/usr/local"

# Check if running as root
if [ "$EUID" -ne 0 ]; then
    echo "Please run as root (use sudo)"
    exit 1
fi

echo "Uninstalling ScratchBird v0.5.0..."

# Stop and disable service
systemctl stop scratchbird || true
systemctl disable scratchbird || true

# Remove service file
rm -f "/etc/systemd/system/scratchbird.service"
systemctl daemon-reload

# Remove binaries
rm -f "$INSTALL_PREFIX/bin"/sb_*
rm -f "$INSTALL_PREFIX/bin/scratchbird"

# Remove libraries
rm -f "$INSTALL_PREFIX/lib"/libsbclient*

# Remove headers
rm -rf "$INSTALL_PREFIX/include/scratchbird"

# Remove configuration (ask user)
read -p "Remove configuration files? (y/N): " -n 1 -r
echo
if [[ $REPLY =~ ^[Yy]$ ]]; then
    rm -rf "/etc/scratchbird"
fi

# Remove data (ask user)
read -p "Remove data directory? (y/N): " -n 1 -r
echo
if [[ $REPLY =~ ^[Yy]$ ]]; then
    rm -rf "/var/lib/scratchbird"
fi

# Remove logs (ask user)
read -p "Remove log directory? (y/N): " -n 1 -r
echo
if [[ $REPLY =~ ^[Yy]$ ]]; then
    rm -rf "/var/log/scratchbird"
fi

echo "ScratchBird uninstalled successfully!"
