#!/bin/bash
# ScratchBird Installation Script

set -e

INSTALL_PREFIX="/usr/local"
SCRATCHBIRD_USER="scratchbird"
SCRATCHBIRD_GROUP="scratchbird"

# Check if running as root
if [ "$EUID" -ne 0 ]; then
    echo "Please run as root (use sudo)"
    exit 1
fi

echo "Installing ScratchBird v0.5.0..."

# Create user and group
if ! getent group "$SCRATCHBIRD_GROUP" > /dev/null 2>&1; then
    groupadd "$SCRATCHBIRD_GROUP"
fi

if ! getent passwd "$SCRATCHBIRD_USER" > /dev/null 2>&1; then
    useradd -r -g "$SCRATCHBIRD_GROUP" -d /var/lib/scratchbird -s /bin/false "$SCRATCHBIRD_USER"
fi

# Create directories
mkdir -p "$INSTALL_PREFIX/bin"
mkdir -p "$INSTALL_PREFIX/lib"
mkdir -p "$INSTALL_PREFIX/include"
mkdir -p "/etc/scratchbird"
mkdir -p "/var/lib/scratchbird"
mkdir -p "/var/log/scratchbird"

# Install binaries
cp bin/* "$INSTALL_PREFIX/bin/"
chmod +x "$INSTALL_PREFIX/bin"/sb_*
chmod +x "$INSTALL_PREFIX/bin"/scratchbird

# Install libraries
cp lib/* "$INSTALL_PREFIX/lib/"

# Install headers
cp -r include/* "$INSTALL_PREFIX/include/"

# Install configuration
cp conf/* "/etc/scratchbird/"

# Set permissions
chown -R "$SCRATCHBIRD_USER:$SCRATCHBIRD_GROUP" "/var/lib/scratchbird"
chown -R "$SCRATCHBIRD_USER:$SCRATCHBIRD_GROUP" "/var/log/scratchbird"
chown -R root:root "/etc/scratchbird"
chmod 644 "/etc/scratchbird"/*

# Create systemd service
cat > "/etc/systemd/system/scratchbird.service" << 'SYSTEMD_EOF'
[Unit]
Description=ScratchBird Database Server
After=network.target

[Service]
Type=forking
User=scratchbird
Group=scratchbird
ExecStart=/usr/local/bin/scratchbird -d
ExecReload=/bin/kill -HUP $MAINPID
PIDFile=/var/run/scratchbird.pid
Restart=always
RestartSec=5

[Install]
WantedBy=multi-user.target
SYSTEMD_EOF

# Enable and start service
systemctl daemon-reload
systemctl enable scratchbird

echo "ScratchBird installed successfully!"
echo "To start the service: sudo systemctl start scratchbird"
echo "To check status: sudo systemctl status scratchbird"
echo "Configuration files: /etc/scratchbird/"
echo "Data directory: /var/lib/scratchbird/"
echo "Log directory: /var/log/scratchbird/"
